export default interface UploadFiles {
  files: Express.Multer.File[]
}
